
public class StringCountsUsingArray {
	public static void main(String[] args) {
		String str = "A B ABCABC AB A B ";
		int[] arrayChar = new int[52];
		int countDuplicate=0, countUnique=0, spaceCount=0;
		
		for (char ch : str.toCharArray()) {
		//System.out.println(ch);
			if(ch!=' ' && ch >='A' && ch<='Z')
				arrayChar[ch-'A'] = (arrayChar[ch-'A'] == 0) ? 1 : ++arrayChar[ch-'A'];
			else if(ch!=' ' && ch >='a' && ch<='z')
				arrayChar[ch-'a' + 26] = (arrayChar[ch-'a' + 26] == 0) ? 1 : ++arrayChar[ch-'a' + 26];
			else if(ch==' ')
				spaceCount++;
		}
		
		for (int i : arrayChar) {
			if(i > 1)
				countDuplicate++;
			else if (i==1) {
				countUnique++;
			}
		}
		System.out.println("The number of uniques char are : " + countUnique);
		System.out.println("The number of spaces are : " + spaceCount);
		System.out.println("The number of duplicate char are : " + countDuplicate);
	}
}
