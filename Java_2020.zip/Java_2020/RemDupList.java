import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.Set;

public class RemDupList {
// 8. Remove duplicate from list
	private static ArrayList<String> removeDuplicates(ArrayList<String> arrayList) {
		// TODO Auto-generated method stub
		Set<String> removeDupSet = new LinkedHashSet<>(arrayList);
		ArrayList<String> removeDupList = new ArrayList<String>();
		for (String string : removeDupSet) {
			removeDupList.add(string);
		}
		return removeDupList;
	}

	public static void main(String[] args) {
		ArrayList<String> arrayList = new ArrayList<String>();
		for (int i = 0; i < args.length; i++) {
			arrayList.add(args[i]);
		}
		arrayList = removeDuplicates(arrayList);
		for (String string : arrayList) {
			System.out.println(string);
		}

	}

}
