
public class PalindromeString {
//18. check Palindrome
	public static Boolean checkPalindrome(String input) {
		String rev = "";
		for (int i = input.length() - 1; i >= 0; i--) {
			rev += input.charAt(i);
		}
		return (rev.equals(input)) ? true : false;

	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		if (checkPalindrome(args[0]))
			System.out.println("The string is Palindrome");
		else
			System.out.println("The string is not Palindrome");
	}

}
