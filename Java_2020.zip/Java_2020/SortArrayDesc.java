import java.util.Arrays;

public class SortArrayDesc {
//17.Sort array in descending order
	public static int[] sortArray(int[] arr) {
		Arrays.sort(arr);
		reverse(arr);
		return arr;

	}

	public static void reverse(int[] input) {
		int last = input.length - 1;
		int middle = input.length / 2;
		for (int i = 0; i <= middle; i++) {
			int temp = input[i];
			input[i] = input[last - i];
			input[last - i] = temp;
		}
	}

	public static void main(String[] args) {
		int[] arr = new int[args.length];
		for (int i = 0; i < args.length; i++) {
			arr[i] = Integer.parseInt(args[i]);
		}
		int[] num = sortArray(arr);
		for (int i = 0; i < num.length; i++) {
			System.out.println("The sorted array is " + num[i]);
		}
	}
}
