import java.util.Set;
import java.util.HashSet;

public class RemoveDuplicates {
// 16. Delete duplicates in an array
	public static Integer[] removeDuplicates(int[] input) {

		Set<Integer> resultSet = new HashSet<Integer>();

		for (int integer : input) {
			resultSet.add(integer);
		}

		Integer[] resultArray = new Integer[resultSet.size()];

		int i = 0;
		for (Integer integer : resultSet) {
			resultArray[i++] = integer;
		}
		return resultArray;
	}

	public static void main(String[] args) {
		int[] input = new int[args.length];
		for (int i = 0; i < args.length; i++) {
			input[i] = Integer.parseInt(args[i]);
		}

		for (Integer i : removeDuplicates(input)) {
			System.out.println(i);
		}
	}
}
