
public class GCFandLCM {
	//15. Calculate GCF and LCM
	private static int GCF(int a, int b) {
		if (b == 0)
			return a;
		else
			return GCF(b, a % b);
	}

	private static int LCM(int a, int b) {
		return ((a * b) / GCF(a, b));
	}

	public static void main(String[] args) {
		int a = Integer.parseInt(args[0]);
		int b = Integer.parseInt(args[1]);
		System.err.println("GCF of two numbers is- " + GCF(a, b) + "\nLCM of two numbers is- " + LCM(a, b));
	}
}
