
public class RemoveDuplicateUsingArray {
	// different approach for removing duplicate char in string
	
	public static int getIndex(char ch) {
		return (ch>='A' && ch<='Z')?ch-'A':ch-'a'+26;
	}
	
	public static void main(String[] args) {
		String input = "sssSSSShhhhHHHH I am here";
		
		int[] arrayChar = new int[52];
		
		String result = "";
		for (char ch: input.toCharArray()) {
			if(ch!=' ')
				arrayChar[getIndex(ch)] = (arrayChar[getIndex(ch)] == 0) ? 1 : ++arrayChar[getIndex(ch)];
		}
		
		for (char ch : input.toCharArray()) {
			if(ch == ' ')
				result += ch;
			else if(arrayChar[getIndex(ch)] >= 1) {
				result += ch;
				arrayChar[getIndex(ch)] = 0;
			}
		
		}
	System.out.println(result);
	}
	
	
}
