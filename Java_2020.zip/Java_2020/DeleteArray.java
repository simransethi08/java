import java.util.Arrays;

public class DeleteArray {
	//20. Insert an element in an array at position = x, remaining elements should be pushed to the right

		private static int[] deleteArray(int[] arr, int x) {
			int[] newArr = new int[arr.length - 1];
			for (int i = 0; i < newArr.length; i++) {
				if (i < x - 1) {
					newArr[i] = arr[i];
				} else if (i >=x - 1) {
					newArr[i] =  arr[i+1];
				}
			}
			return newArr;
		}

		public static void main(String[] args) {
			int[] arr = new int[args.length - 1];
			int pos = Integer.parseInt(args[0]);
			int j = 0;
			for (int i = 1; i < args.length; i++) {
				arr[j] = Integer.parseInt(args[i]);
				j++;
			}
			System.out.println("The old array is " + Arrays.toString(arr));
			int[] num = deleteArray(arr, pos);
			System.out.println("The new array is " + Arrays.toString(num));

		}
}
