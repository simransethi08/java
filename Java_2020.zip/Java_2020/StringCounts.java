import java.util.HashMap;
import java.util.Map;

public class StringCounts {
// 13. Count spaces, duplicates and Uniques for given string

	private static int countUniqueChar(String string) {
		int count=0;
		char[] str=string.trim().toCharArray();
		Map<Character, Integer> map=new HashMap<Character, Integer>();
		for(char s:str) {
			if(s!=' ') {
				if(map.containsKey(s)) {
					map.put(s, map.get(s)+1);					
				}
				else {
					map.put(s, 1);
				}
			}
		}
		for(Map.Entry mapElements:map.entrySet()) {
			if((Integer)mapElements.getValue()==1) {
				count++;
			}
		}
		return count;
	}

	private static int countDuplicateChar(String string) {
		int count=0;
		char[] str=string.trim().toCharArray();
		Map<Character, Integer> map=new HashMap<Character, Integer>();
		for(char s:str) {
			if(s!=' ') {
				if(map.containsKey(s)) {
					map.put(s, map.get(s)+1);					
				}
				else {
					map.put(s, 1);
				}
			}
		}
		for(Map.Entry mapElements:map.entrySet()) {
			if(!((Integer)mapElements.getValue()==1)) {
				count++;
			}
		}
		return count;
	}

	public static int countSpaces(String str) {
		int spaceCount = 0;
		for (char c : str.toCharArray()) {
			if (c == ' ') {
				spaceCount++;
			}
		}
		return spaceCount;
	}

	public static void main(String[] args) {
		String str = "A B ABCABC AB A B ";
		if (str != null) {
			int unique = countUniqueChar(str);
			int spaces = countSpaces(str);
			int duplicate = countDuplicateChar(str);
			System.out.println("The number of uniques char are : " + unique);
			System.out.println("The number of spaces are : " + spaces);
			System.out.println("The number of duplicate char are : " + duplicate);
		}
	}
}
