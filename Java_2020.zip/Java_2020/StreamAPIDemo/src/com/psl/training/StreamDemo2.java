package com.psl.training;

import java.util.DoubleSummaryStatistics;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Function;
import java.util.stream.Collectors;

import com.psl.training.model.Employee;
import com.psl.training.model.Gender;
import com.psl.training.service.EmployeeService;

public class StreamDemo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<Employee> empList = new EmployeeService().getEmployees();

		DoubleSummaryStatistics statistics = empList.stream().collect(
				Collectors.summarizingDouble(Employee::getSalary));
		// System.out.println(statistics);

		getEmployeesByText(empList, "e").forEach(System.out::println);
		;

		BiConsumer<? super String, ? super List<Employee>> printEmployees = (k,
				v) -> {
			System.out.println(k);
			v.forEach(System.out::println);
		};
		getEmployeesByDepartment(empList).forEach(printEmployees);
		System.out.println("------------- By city ---------------");
		getEmployeesByCity(empList).forEach(printEmployees);
		System.out.println("------------- By Gender ---------------");
		getEmployeesByGender(empList).forEach(
				(k,v)->{
					System.out.println((k?Gender.MALE :Gender.FEMALE));
					v.forEach(System.out::println);
					});
	}

	static List<String> getNameByText(List<Employee> empList, String subString) {

		return empList.stream() // Stream<Employee>
				.map(Employee::getEmpName)// map(e-> e.getEmpName) //
											// Stream<String>
				.filter(nm -> nm.contains(subString)) // Stream<String>
				.collect(Collectors.toList()); // List<String>
	}

	static List<Employee> getEmployeesByText(List<Employee> empList,
			String subString) {

		return empList.stream().filter(e -> e.getEmpName().contains(subString))
				.collect(Collectors.toList());
	}

	static Map<String, List<Employee>> getEmployeesByDepartment(
			List<Employee> empList) {

		return empList.stream().collect(
				Collectors.groupingBy(Employee::getDepartment));

	}

	static Map<String, List<Employee>> getEmployeesByCity(List<Employee> empList) {

		Function<Employee, String> keyMapper = (e) -> e.getAddress().getCity();

		return empList.stream().collect(
				Collectors.groupingBy(keyMapper = (e) -> e.getAddress()
						.getCity()));

	}

	static Map<Boolean, List<Employee>> getEmployeesByGender(
			List<Employee> empList) {

		
		return empList.stream().collect(Collectors.partitioningBy((e)-> e.getGender().equals(Gender.MALE)));

	}
}
