package com.psl.training;

import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

public class StreamBasics {

	public static void main(String[] args) {

		Stream<Integer>  intStream= IntStream.of(10,20,34,234,345,35,2345,345).boxed();
		
		intStream.sorted().forEach(System.out::println);
		
		intStream =IntStream.range(10, 20).boxed();
		
		List<Integer> numbers=intStream.collect(Collectors.toList());
		
		numbers.forEach(System.out::println);
		
		//long totalno=intStream.count();
		
		//System.out.println(totalno);
		
		
		String names[]= {"Tom","Jack","Zeba","Bill","Aadi","Harry","Ram","Krish"};
		
		List<String> nameList = Arrays.asList(names);
		Stream<String> nameStream= nameList.stream();
		
		Predicate<? super String> contains_a = name -> { 
			System.out.println(Thread.currentThread().getName());
			
			return name.contains("a"); };
		
		long count=nameStream.filter(contains_a).count();
		
		nameList.parallelStream()
		.filter(contains_a)
		.sequential()
		.sorted()
		.forEach((x)->System.out.println(x)); // terminal operation 
				
	}

}
