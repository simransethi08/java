package com.psl.training.model;

public enum Gender {
MALE,FEMALE
}
