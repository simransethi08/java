package com.psl.training.model;


public class Employee {

	private int empid;
	private String empName;
	private Address address;
	private double salary;
	private String department;
	private Gender gender;
	
	public Employee() {
		// TODO Auto-generated constructor stub
	}

	public Employee(int empid, String empName, Address address, double salary,
			String department, Gender gender) {
		super();
		this.empid = empid;
		this.empName = empName;
		this.address = address;
		this.salary = salary;
		this.department = department;
		this.gender = gender;
	}

	public int getEmpid() {
		return empid;
	}

	public void setEmpid(int empid) {
		this.empid = empid;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public Gender getGender() {
		return gender;
	}

	public void setGender(Gender gender) {
		this.gender = gender;
	}

	@Override
	public String toString() {
		return "Employee [empid=" + empid + ", empName=" + empName
				+ ", address=" + address + ", salary=" + salary
				+ ", department=" + department + ", gender=" + gender + "]";
	}
	
	
	
}
