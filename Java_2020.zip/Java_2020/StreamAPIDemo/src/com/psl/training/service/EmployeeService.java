package com.psl.training.service;

import java.util.ArrayList;
import java.util.List;

import com.psl.training.model.Address;
import com.psl.training.model.Employee;
import com.psl.training.model.Gender;

public class EmployeeService {

	public List<Employee> getEmployees(){
		
		List<Employee> employeeList=new ArrayList<>();
		employeeList.add(new Employee(101, "Beena", new Address("Pune"), 30400, "IT", Gender.FEMALE));
		employeeList.add(new Employee(110, "Rama", new Address("Pune"), 4700, "IT", Gender.MALE));
		employeeList.add(new Employee(102, "Arjun", new Address("Mumbai"), 40400, "IT", Gender.FEMALE));
		employeeList.add(new Employee(104, "Geeta", new Address("Pune"), 34400, "Sales", Gender.FEMALE));
		employeeList.add(new Employee(103, "Peter", new Address("Pune"), 43400, "IT", Gender.MALE));
		employeeList.add(new Employee(105, "Tom", new Address("Mumbai"), 87400, "IT", Gender.MALE));
		employeeList.add(new Employee(107, "Harry", new Address("Pune"), 54400, "Production", Gender.MALE));
		employeeList.add(new Employee(106, "Beena", new Address("Pune"), 54400, "IT", Gender.FEMALE));
		employeeList.add(new Employee(108, "Chanda", new Address("Mumbai"), 60000, "IT", Gender.FEMALE));
		employeeList.add(new Employee(109, "Eka", new Address("Pune"), 30400, "IT", Gender.FEMALE));
		employeeList.add(new Employee(111, "Dipa", new Address("Pune"), 30400, "IT", Gender.FEMALE));
		return employeeList;
		
	}
	
	
	
	
}
