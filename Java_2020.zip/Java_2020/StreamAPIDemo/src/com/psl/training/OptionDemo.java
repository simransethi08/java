package com.psl.training;

import java.util.Optional;

public class OptionDemo {
	public static void main(String[] args) throws Exception {

		String name = null;
		Optional<String> nm=Optional.ofNullable(name);
		System.out.println(nm.orElseThrow(()-> new Exception("Name not Found")).toUpperCase());
	}
}
