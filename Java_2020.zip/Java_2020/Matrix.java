
public class Matrix {
	private static void upperTriangle(int[][] matrix, int n, int m) {
		int sum=0;
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < m; j++) {
				if (j < i) {
					System.out.print(" ");
				} else {
					System.out.print(matrix[i][j]);
					sum+=matrix[i][j];
				}
			}
			System.out.println();
		}
		System.out.println("Sum of UpperTriangle is "+sum);
	}

	private static void lowerTriangle(int[][] matrix, int n, int m) {
		int sum=0;
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < m; j++) {
				if (j > i) {
					System.out.print(" ");
				} else {
					System.out.print(matrix[i][j]);
					sum+=matrix[i][j];
				}
			}
			System.out.println();
		}
		System.out.println("Sum of LowerTriangle is "+sum);
	}

	public static void main(String[] args) {
		int[][] matrix = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };
		int row = 3, col = 3;
		upperTriangle(matrix, row, col);
		lowerTriangle(matrix, row, col);

	}
}
