/* Save this in a file called Main.java to compile and test it */

/* Do not add a package declaration */
import java.util.*;
import java.io.*;

/* You may add any imports here, if you wish, but only from the 
   standard library */
   //for "JavaaavJ"=1, "JJvaJ"=-1,"JaavvavJ"=0

public class Main {
    public static int process(String str) {
       int flag = 0;
		char[] ch = str.toCharArray();
		if (ch.length % 2 == 0) {
			for (int i = 0; i < ch.length / 2; i++) {
				for (int j = ch.length / 2; j < ch.length; j++) {
					if (ch[i] == ch[j]) {
						flag=1;
					}
				}
				if(flag==0)
					return 0;
			}
			return 1;
		}
		return -1;
    }

    public static void main (String[] args) {
        try {
            Scanner in = new Scanner(new BufferedReader(new FileReader("input.txt")));
            String line = in.nextLine().trim();
            int retVal = process(line);
            PrintWriter output = new PrintWriter(new BufferedWriter(new FileWriter("output.txt")));
            output.println("" + retVal);
            output.close();
        } catch (IOException e) {
            System.out.println("IO error in input.txt or output.txt");
        }
    }
}
