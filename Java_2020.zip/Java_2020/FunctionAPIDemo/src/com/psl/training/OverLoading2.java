package com.psl.training;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Map;
import java.util.TreeMap;

import javax.swing.text.StyledEditorKit.ForegroundAction;

public class OverLoading2 {

	public void m1(int a,float b) {
		System.out.println("int and float");
	}
	public String m1(float a,int b) {
		System.out.println("float and int");
		return "Hi";
	}
	void removeNegative(ArrayList<Integer> a) {
	    int i=0;
	    while(i<a.size())
	        if (a.get(i) < 0) 
	            a.remove(i);
	        else
	            i++;
	}
	
	public static void main(String[] args) {
		OverLoading2 a=new OverLoading2();
		a.m1(10, 10f);
		a.m1(10f, 10);
		//a.m1(10, 10);
		//a.m1(10f, 10f);
		B t = new B();
		Map<String,Integer> l = new TreeMap<String,Integer>();
		ArrayList<Integer> am= new ArrayList<Integer>();
		am.add(5);
		am.add(-4);
		a.removeNegative(am);
		for (Integer integer : am) {
			System.out.println(integer);
		}
		
		
	
}
}