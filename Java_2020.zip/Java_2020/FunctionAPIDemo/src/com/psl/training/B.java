package com.psl.training;

class B extends A {
	public String f1() {
        return "f1t";
    }
    public static void calculate(String[] args) {
    }
}