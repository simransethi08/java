package com.psl.training;

public class MyException extends Exception {

}
