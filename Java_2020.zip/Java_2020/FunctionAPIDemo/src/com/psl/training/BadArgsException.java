package com.psl.training;
import com.psl.training.MyException;

public class BadArgsException extends Exception {

}
