package com.psl.training;

import java.time.LocalDate;
import java.util.function.BiFunction;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.IntFunction;
import java.util.function.Predicate;
import java.util.function.Supplier;


public class UsingFunctionAPI {

	public static void main(String[] args) {
		
		
		// create printMessage 
		Consumer<String> printMessage=(name)-> System.out.println(" Hello "+name+"!");

		//Function<Integer, Integer> square=(num1)-> num1*num1;
		IntFunction<Integer> square=(num1)->num1*num1;
		
		BiFunction<Integer, Integer, String> adder= 
				(n1,n2)->" Addition of "+n1 +" and "+n2 + "= "+(n1+n2);
		
		Supplier<LocalDate> dateSupplier=()->LocalDate.now();
		
		Predicate<Integer> isEven=(no)-> no%2==0;
	
		
		printMessage.accept("Tom");
		
		
		System.out.println(square.apply(5));
		
		System.out.println( adder.apply(10, 20));
		
		System.out.println(dateSupplier.get());
		
		System.out.println(" is 5 even ?"+isEven.test(5));
		
		
	
	}
}
