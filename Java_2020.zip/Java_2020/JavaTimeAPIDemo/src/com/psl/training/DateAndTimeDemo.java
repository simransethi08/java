package com.psl.training;

import java.time.LocalDate;
import java.time.Period;
import java.time.temporal.ChronoUnit;

public class DateAndTimeDemo {
	public static void main(String[] args) {

			LocalDate d1=LocalDate.of(2020, 5, 1);
			LocalDate d2=LocalDate.now();
			
			Period period=Period.between(d1, d2);
			System.out.println(period.getYears());
			System.out.println(period.getMonths());
			System.out.println(period.getDays());
			
		System.out.println(ChronoUnit.DAYS.between(d1, d2));
		
	}
}
