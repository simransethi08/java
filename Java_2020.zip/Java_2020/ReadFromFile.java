import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.HashMap;

public class ReadFromFile {
 private static Map<String,Integer> fetchCities(List<String> input){
	 Map<String,Integer> output=new HashMap<>();
	 List<String> cities=new ArrayList<>();
	 for(String line:input) {
		 String data[]=line.split(",");
		 cities.add(data[2]);
	 }
	 
	 for(String city:cities) {
		 if(output.containsKey(city)) {
			 output.put(city,output.get(city)+1);
		 }
		 else
			 output.put(city, 1);
	 }
	return output;
	 
 }
	public static void main(String[] args) {
		List<String> input = new ArrayList<String>();
		try {
			input = Files.lines(new File("input1.txt").toPath()).map(s -> s.trim()).filter(s -> !s.isEmpty())
					.collect(Collectors.toList());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Map<String,Integer> cities=new HashMap<>();
		cities=fetchCities(input);
		for(Map.Entry city:cities.entrySet()) {
			System.out.println(city.getKey()+" : "+city.getValue());
		}
		
	}
}
