
public class Fibonacci {
	static int a = 0;
	static int b = 1;
	static int sum = 0;

	private static void fibonacci(int n) {
		if (n > 0) {
			sum = a + b;
			a = b;
			b = sum;
			System.out.print(" " + sum);
			fibonacci(n - 1);
		}
	}

	public static void main(String[] args) {
		int count = Integer.parseInt(args[0]);
		System.out.print(a + " " + b);
		fibonacci(count - 2);
	}
}
