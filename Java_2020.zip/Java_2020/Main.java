/* Save this in a file called Main.java to compile and test it */

/* Do not add a package declaration */
import java.util.*;
import java.io.*;

/* You may add any imports here, if you wish, but only from the 
   standard library */

public class Main {
    public static int processData(ArrayList<String> array) {
        /* 
         * Modify this method to process `array` as indicated
         * in the question. At the end, return the appropriate value.
         *
         * Please create appropriate classes, and use appropriate
         * data structures as necessary.
         *
         * Do not print anything in this method.
         *
         * Submit this entire program (not just this method)
         * as your answer
         */
    	
    	Map<Integer, List<Integer>> dept = new TreeMap<Integer, List<Integer>>(Collections.reverseOrder());
		
    	for(String line : array) {
    		String data[] = line.split(",");
    	
    		int keyDept = Integer.parseInt(data[2].trim());
    		int valueSalary = Integer.parseInt(data[3].trim());
    		
    		if(dept.containsKey(keyDept)) {
    			dept.get(keyDept).add(valueSalary);
    		}else {
    			List<Integer> salary = new ArrayList<Integer>();
    			salary.add(valueSalary);
    	 		dept.put(keyDept, salary);
    		}
    	}
    	
    	List<Integer> sortedList = new ArrayList<Integer>();
		sortedList = dept.get(dept.keySet().iterator().next());
		Collections.sort(sortedList);
		return sortedList.get(0);
        
    }

    public static void main (String[] args) {
        ArrayList<String> inputData = new ArrayList<String>();
        try {
            Scanner in = new Scanner(new BufferedReader(new FileReader("D:\\eclipse_workspace\\SimplePracticeProject\\src\\input.txt")));
            while(in.hasNextLine()) {
                String line = in.nextLine().trim();
                if (!line.isEmpty()) // Ignore blank lines
                    inputData.add(line);
            }
            int retVal = processData(inputData);
            PrintWriter output = new PrintWriter(new BufferedWriter(new FileWriter("D:\\eclipse_workspace\\SimplePracticeProject\\src\\output.txt")));
            output.println("" + retVal);
            output.close();
        } catch (IOException e) {
            System.out.println("IO error in input.txt or output.txt");
        }
    }
}
