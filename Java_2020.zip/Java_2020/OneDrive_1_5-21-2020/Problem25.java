
 public class Problem25{
	 public void printValue(){
		 int row=4;
		 int [] array = new int[row];
		 int counter=0;
		// int j=0;
		 for(int i =1 ;i<row*row;i++){
			 //System.out.println(i);
			 
			 int value =i;
			 if(!(i%2 == 0)){
				 //System.out.println(""+value+"j:"+j);
				 array[counter] = value;
				 counter++;
				 
			 }
			 if(counter == row)
				 break;
		 }
		
	//int count =4;
for(int i=0; i<array.length;i++){
	counter =row;
	
	System.out.printf("%" + (counter - i) *2+ "s", "");
	//System.out.println(""+counter);
	int innerCounter =counter;
	for(int j=0; j<array.length;j++){
	 
	 if(i<j)
		 break;
	System.out.printf("%" + (row )+ "s", array[i]); 
	  //System.out.printf("%"+(innerCounter)+"d",array[i]);
    //System.out.printn("%"+array.length+"d");
	 //innerCounter --;
	}
	 System.out.println("");
}
for(int i=array.length-1; i>=0;i--){
	counter =row;
	System.out.printf("%" + (counter - i) *2+ "s", "");
	for(int j=0; j<array.length;j++){
	 if(i<j)
break;		 
	 System.out.printf("%" + (row )+ "s", array[i]); 
	  
	}
	 System.out.println("");
}	
		  

	 }
	 
	
	 public static void main(String[] arg){
		 Problem25 obj1= new Problem25();
		 
		 
		 obj1.printValue();
		 //obj1.getSpaceCount("Find no of spaces in the given string");
		 // obj1.getUniqueCharacter("aAmit");
		 // obj1.getDuplicateCharacter("Aamit");
		 
		 
		 
		 
	 }
 }