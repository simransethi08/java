
import java.util.Set;
import java.util.Map;
import java.util.HashSet;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Iterator;
import java.util.Map.Entry;
 public class Problem23{
	 
	 public int factorial(int no){
		 int f;
		 for(f =1;no>1 ;no--){
			 f*=no;
		 }
		 return f;
	 }
	 public int method(int i,int j){
		 return factorial(i)/(factorial(i-j)*factorial(j));
	 }
	 public void printValue(int no){
		 for(int i=0;i<=no;i++){
			 for(int j=0;j<=no-i;j++){
				 System.out.print("");
			 }
			 for(int j=0;j<=i;j++){
				 System.out.print(""+method(i,j));
			 }
			 System.out.println();
		 }
		 
	 }
	 public static void main(String[] arg){
		 Problem23 obj1= new Problem23();
		 int inputString =5;
		 obj1.printValue(inputString);
		 //obj1.getSpaceCount("Find no of spaces in the given string");
		 // obj1.getUniqueCharacter("aAmit");
		 // obj1.getDuplicateCharacter("Aamit");
		 
		 
		 
		 
	 }
 }