
 public class Problem24{
	 public void printValue(int inputString [][]){
		 int r=3, c=3;
		 int upperSum =0;
		 int lowerSum =0;
		 	 System.out.println("Input Array");
		 for(int i=0; i<r;i++){
			 for(int j=0; j<c;j++){
				 System.out.print(inputString[i][j]);
			 }
			 System.out.println("");
		 }
		  System.out.println("Upper Trianle");
		 for(int i=0; i<r;i++){
			 for(int j=0; j<c;j++){
				 if(i<=j){
					  System.out.print(inputString[i][j]);
					  upperSum+=inputString[i][j];
				 }
			 }
			 System.out.println("");
		 }
		 System.out.println("Lower Trianle");
		  for(int i=0; i<r;i++){
			 for(int j=0; j<c;j++){
				 if(j<=i){
					 System.out.print(inputString[i][j]);
					  lowerSum+=inputString[i][j];
				 }
			 }
			 System.out.println("");
		  }
		   System.out.println("upperSum: "+upperSum+", lowerSum: "+lowerSum);
	 }
	 
	
	 public static void main(String[] arg){
		 Problem24 obj1= new Problem24();
		 int inputString [][]={{1,2,3},{4,5,6},{7,8,9}};
		 
		 obj1.printValue(inputString);
		 //obj1.getSpaceCount("Find no of spaces in the given string");
		 // obj1.getUniqueCharacter("aAmit");
		 // obj1.getDuplicateCharacter("Aamit");
		 
		 
		 
		 
	 }
 }