package com.psl.training;


// Functional Interface
interface MyInterface1{
	void greetingMessage(String name)throws Exception;
}

interface MyInterface2{
	String greet(String name);
}
interface MyInterface{
	String message();
}

public class LamdaDemo2 {
	public static void main(String[] args) {

		MyInterface lambdaRef1= ()->" Welcome to Lambdas...";
		
		MyInterface1 labdaRef2= (String x)-> {
			if(x==null) throw new Exception(); 
			System.out.println(x);
			
		};
		
		MyInterface2 lambdaRef3 = (str) -> {return "Welcome "+str;};
	}
	
	public static void printMessage(MyInterface1 ref1) throws Exception {
		ref1.greetingMessage("Harry");
	}
}
