package com.psl.training;



interface MessageI{
	void message();
	default void disp(){
		
		System.out.println(" Default impl.....");
	}
	
	default String getMessage(){
		return "Hello from default";
	}
	
	static void doThis(){}
}

class Test{

	
	public static void message() {
		System.out.println(" this is Method Reference....");
	}
	
	
	public static String getMessage() {
		
		return "returning hello from overrdien";
	}
	
}

public class LambdaDemo1 {

	public static void main(String[] args) {
		LambdaDemo1 obj=new LambdaDemo1();
		
		MessageI noNamedClass=new MessageI() {
			
			@Override
			public void message() {
				System.out.println("Hello...");
				
			}
		
		};// this is no named classes ;
		
		// Lambda Exression
		
		MessageI lambdaRef=()->{
			System.out.println(" Labmda message...");
			System.out.println("This is next line...");
		};
		
		
		lambdaRef.message();
		noNamedClass.message();
		
			//obj.printMessage(lambdaRef);// passing lambda ref as a param
			 //obj.printMessage(noNamedClass); // reference of no named class
			
			obj.printMessage(()->System.out.println("This is method reference message..."));
			obj.printMessage(Test::message); // 
				
	}
	
	public void printMessage(MessageI arg){
		
		arg.message();
		System.out.println(arg.getMessage());
		
	}
}
