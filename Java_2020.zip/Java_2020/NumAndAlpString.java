import java.util.ArrayList;
import java.util.List;

public class NumAndAlpString {
	//1. Find count of numberic and non-numeric String in Lis of Strings.
	public static int checkString(List<String> strList) {
		int count = 0;
		for (String str : strList) {
			try {
				Integer.parseInt(str);
			} catch (NumberFormatException nfe) {
				count++;
			}
		}
		return count;
	}

	public static void main(String[] args) {
		ArrayList<String> arrayList = new ArrayList<String>();
		for (int i = 0; i < args.length; i++) {
			arrayList.add(args[i]);
		}
		int count=checkString(arrayList);
		System.out.println("Numeric count: " + (arrayList.size()-count) + "\nString count: " + count);
	}
}
